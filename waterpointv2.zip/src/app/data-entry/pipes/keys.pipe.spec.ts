/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { KeysPipe } from './keys.pipe.ts';

describe('Pipe: Keys', () => {
  it('create an instance', () => {
    let pipe = new KeysPipe();
    expect(pipe).toBeTruthy();
  });
});
