import { HideOptionsPipe } from './hide-options.pipe';

describe('HideOptionsPipe', () => {
  it('create an instance', () => {
    const pipe = new HideOptionsPipe();
    expect(pipe).toBeTruthy();
  });
});
