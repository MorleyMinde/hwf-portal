import { FilterOrgUnitAttributesPipe } from './filter-org-unit-attributes.pipe';

describe('FilterOrgUnitAttributesPipe', () => {
  it('create an instance', () => {
    const pipe = new FilterOrgUnitAttributesPipe();
    expect(pipe).toBeTruthy();
  });
});
