/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { DataElementFinderPipe } from './data-element-finder.pipe.ts';

describe('Pipe: DataElementFinder', () => {
  it('create an instance', () => {
    let pipe = new DataElementFinderPipe();
    expect(pipe).toBeTruthy();
  });
});
