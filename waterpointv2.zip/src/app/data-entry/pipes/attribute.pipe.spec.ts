/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { AttributePipe } from './attribute.pipe.ts';

describe('Pipe: Attribute', () => {
  it('create an instance', () => {
    let pipe = new AttributePipe();
    expect(pipe).toBeTruthy();
  });
});
