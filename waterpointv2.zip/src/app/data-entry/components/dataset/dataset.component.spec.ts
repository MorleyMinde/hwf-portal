/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { DatasetComponent } from './dataset.component';

describe('Component: Dataset', () => {
  it('should create an instance', () => {
    let component = new DatasetComponent();
    expect(component).toBeTruthy();
  });
});
