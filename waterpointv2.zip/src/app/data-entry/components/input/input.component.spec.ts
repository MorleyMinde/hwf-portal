/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { InputComponent } from './input.component.ts';

describe('Component: Input', () => {
  it('should create an instance', () => {
    let component = new InputComponent();
    expect(component).toBeTruthy();
  });
});
