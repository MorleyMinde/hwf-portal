/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { CoordinateComponent } from './coordinate.component';

describe('Component: Coordinate', () => {
  it('should create an instance', () => {
    let component = new CoordinateComponent();
    expect(component).toBeTruthy();
  });
});
