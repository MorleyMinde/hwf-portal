/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { SubOrganisationUnitsComponent } from './sub-organisation-units.component.ts';

describe('Component: SubOrganisationUnits', () => {
  it('should create an instance', () => {
    let component = new SubOrganisationUnitsComponent();
    expect(component).toBeTruthy();
  });
});
