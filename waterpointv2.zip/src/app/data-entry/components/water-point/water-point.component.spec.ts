/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { WaterPointComponent } from './water-point.component.ts';

describe('Component: WaterPoint', () => {
  it('should create an instance', () => {
    let component = new WaterPointComponent();
    expect(component).toBeTruthy();
  });
});
